from flask import Flask,render_template,request
import boto3
translate = boto3.client(service_name='translate', region_name='us-east-1', use_ssl=True)

app = Flask(__name__)
 
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/', methods = ['POST'])
def get_value():
    output = request.form.to_dict()
    nm = output['pname']
    lg = output['lname']
    img = output['fname']

    ## saving file to static
    #with open('translate\\static', 'wb')as f:
    #    f.write()

    ## Creating bucket
    s3 = boto3.client('s3',region_name = 'us-east-1')
    bucket = s3.create_bucket(Bucket = 'pradyumnproject')

    ## Uploading file in the bucket
    with open("FILE_NAME", "rb") as f:
        s3.upload_fileobj(f, "BUCKET_NAME", "OBJECT_NAME")

    result = translate.translate_text(Text = nm, 
            SourceLanguageCode="en", TargetLanguageCode = lg)
    translated_text = result.get('TranslatedText')
    ## "multipart/form-data"
    return render_template('result.html', tt = translated_text, ii = img)
 
if __name__ == '__main__':
    app.run(debug=True)