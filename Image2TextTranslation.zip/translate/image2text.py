from flask import Flask,render_template,request
from werkzeug.utils import secure_filename
import matplotlib.pyplot as plt
import os
import boto3

recognition = boto3.client('rekognition', region_name = 'us-east-1')
translate = boto3.client(service_name='translate', region_name='us-east-1', use_ssl=True)

app = Flask(__name__)
 
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/', methods = ['POST'])
def get_value():
    output = request.form.to_dict()
    lg = output['lname']
    img = request.files['fname']

    ## saving file to static
    filename = secure_filename(img.filename)
    img.save(os.path.join('C:/Users/Lenovo/Desktop/Proj/translate/static/uploads',filename))
    
    ## Creating bucket
    s3 = boto3.client('s3', region_name = 'us-east-1')

    try:
        response = s3.list_buckets()['Buckets']
        response[1]['Name'] == 'pradyumnproject'
    except:
        #print('Create a new bucket...')
        #print('Creating Bucket.........')
        s3 = boto3.client('s3',region_name = 'us-east-1')
        bucket = s3.create_bucket(Bucket = 'pradyumnproject')
        #print('Bucket Created')
    
    ## Uploading file in the bucket
    with open(os.path.join('C:/Users/Lenovo/Desktop/Proj/translate/static/uploads',filename), "rb") as f:
        s3.upload_fileobj(f, "pradyumnproject", "myimage")

    ## Reading the image using matplotlib

    my_image = plt.imread(os.path.join('static\\uploads', filename))
    #Step 2
    my_image_re = my_image.resize((224,224,3))

    ## AWS Rekognition
    recog = recognition.detect_text(Image={'S3Object':{'Bucket':'pradyumnproject',
                                                        'Name':'myimage'}})
    all_text = ''
    textDetections = recog['TextDetections']
    for text in textDetections:
            all_text = all_text + text['DetectedText'] + ' '

    text = all_text[:-(len(all_text)//2)]

    ## AWS Translate
    result = translate.translate_text(Text = text, 
            SourceLanguageCode="en", TargetLanguageCode = lg)
    translated_text = result.get('TranslatedText')

    return render_template('result.html', org = text, tt = translated_text, ii = my_image_re)
 
if __name__ == '__main__':
    app.run(debug=True)